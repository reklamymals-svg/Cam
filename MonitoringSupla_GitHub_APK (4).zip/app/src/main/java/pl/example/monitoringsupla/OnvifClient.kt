package pl.example.monitoringsupla

import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.time.Instant
import java.util.Base64
import javax.xml.parsers.DocumentBuilderFactory

/** Basic ONVIF Media1 profile discovery. Some cameras require vendor-specific handling. */
object OnvifClient {
    private val http = OkHttpClient.Builder().callTimeout(java.time.Duration.ofSeconds(12)).build()
    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun header(user: String, password: String): String {
        if (user.isBlank()) return ""
        val nonce = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val created = Instant.now().toString()
        val hash = MessageDigest.getInstance("SHA-1").digest(nonce + created.toByteArray(Charsets.UTF_8) + password.toByteArray(Charsets.UTF_8))
        return """<wsse:Security s:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><wsse:UsernameToken><wsse:Username>${escape(user)}</wsse:Username><wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">${Base64.getEncoder().encodeToString(hash)}</wsse:Password><wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">${Base64.getEncoder().encodeToString(nonce)}</wsse:Nonce><wsu:Created>$created</wsu:Created></wsse:UsernameToken></wsse:Security>"""
    }
    private fun request(url: String, user: String, pass: String, action: String, body: String): Document {
        require(url.startsWith("http://") || url.startsWith("https://")) { "Adres ONVIF musi zaczynać się od http:// lub https://" }
        val xml = """<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tds="http://www.onvif.org/ver10/device/wsdl" xmlns:trt="http://www.onvif.org/ver10/media/wsdl" xmlns:tt="http://www.onvif.org/ver10/schema"><s:Header>${header(user, pass)}</s:Header><s:Body>$body</s:Body></s:Envelope>"""
        val req = Request.Builder().url(url).post(xml.toRequestBody("application/soap+xml; charset=utf-8; action=\"$action\"".toMediaType())).build()
        http.newCall(req).execute().use { response ->
            val data = response.body?.bytes() ?: error("Pusta odpowiedź ONVIF")
            if (!response.isSuccessful) error("ONVIF HTTP ${response.code} — sprawdź adres, hasło i obsługę ONVIF")
            val factory = DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = true
                setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
                setFeature("http://xml.org/sax/features/external-general-entities", false)
                setFeature("http://xml.org/sax/features/external-parameter-entities", false)
                setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
                isXIncludeAware = false
                isExpandEntityReferences = false
            }
            val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(data))
            if (doc.getElementsByTagNameNS("*", "Fault").length > 0) error("Kamera odrzuciła żądanie ONVIF (SOAP Fault)")
            return doc
        }
    }
    private fun first(doc: Document, name: String): Element? = doc.getElementsByTagNameNS("*", name).item(0) as? Element
    fun streamUri(deviceUrl: String, username: String, password: String): String {
        val caps = request(deviceUrl, username, password, "http://www.onvif.org/ver10/device/wsdl/GetCapabilities", "<tds:GetCapabilities><tds:Category>Media</tds:Category></tds:GetCapabilities>")
        val media = first(caps, "Media") ?: error("Brak usługi Media ONVIF")
        val mediaUrl = (media.getElementsByTagNameNS("*", "XAddr").item(0)?.textContent ?: error("Brak adresu Media ONVIF")).trim()
        val profiles = request(mediaUrl, username, password, "http://www.onvif.org/ver10/media/wsdl/GetProfiles", "<trt:GetProfiles/>")
        val token = first(profiles, "Profiles")?.getAttribute("token")?.takeIf { it.isNotBlank() } ?: error("Brak profilu wideo ONVIF")
        val uriDoc = request(mediaUrl, username, password, "http://www.onvif.org/ver10/media/wsdl/GetStreamUri", "<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup><trt:ProfileToken>${escape(token)}</trt:ProfileToken></trt:GetStreamUri>")
        val uri = first(uriDoc, "Uri")?.textContent?.trim() ?: error("Kamera nie zwróciła RTSP URI")
        require(uri.startsWith("rtsp://")) { "Kamera zwróciła nieobsługiwany protokół" }
        // Many ONVIF cameras return RTSP URI without credentials.
        val parsed = android.net.Uri.parse(uri)
        return if (username.isNotBlank() && parsed.encodedUserInfo == null) {
            uri.replaceFirst("rtsp://", "rtsp://${java.net.URLEncoder.encode(username, "UTF-8")}:${java.net.URLEncoder.encode(password, "UTF-8")}@")
        } else uri
    }
}
