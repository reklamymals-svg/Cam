package pl.example.monitoringsupla

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val players = mutableListOf<ExoPlayer>()
    private var screen = "dashboard"
    private var stopped = false
    private val http = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var temperature: TextView
    private val refresh = object : Runnable { override fun run() { fetchTemperature(); handler.postDelayed(this, 60_000) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun showDashboard() {
        screen = "dashboard"
        releasePlayers()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 16, 12, 12); setBackgroundColor(Color.rgb(18, 24, 33)) }
        val heading = TextView(this).apply { text = "MONITORING  •  SUPLA"; textSize = 22f; setTextColor(Color.WHITE) }
        root.addView(heading)
        temperature = TextView(this).apply { text = "Temperatura: —"; textSize = 20f; setTextColor(Color.CYAN); setPadding(0, 18, 0, 18) }
        root.addView(temperature)
        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 2 }
        for (i in 1..4) {
            val frame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
            val label = TextView(this).apply { text = "Kamera $i"; setTextColor(Color.WHITE); setPadding(8, 6, 0, 6) }
            frame.addView(label)
            val view = PlayerView(this).apply { useController = false; setBackgroundColor(Color.BLACK) }
            frame.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
            val params = GridLayout.LayoutParams(GridLayout.spec((i - 1) / 2), GridLayout.spec((i - 1) % 2)).apply {
                width = 0; height = 0; columnSpec = GridLayout.spec((i - 1) % 2, 1f); rowSpec = GridLayout.spec((i - 1) / 2, 1f)
                setMargins(3, 3, 3, 3)
            }
            grid.addView(frame, params)
            val url = prefs.getString("camera$i", "").orEmpty()
            if (url.isNotBlank()) {
                try {
                    val player = ExoPlayer.Builder(this).build()
                    player.addListener(object : Player.Listener {
                        override fun onPlayerError(error: PlaybackException) {
                            label.text = "Kamera $i — brak obrazu (sprawdź RTSP / Wi-Fi)"
                        }
                    })
                    player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.playWhenReady = true
                    view.player = player; players.add(player)
                } catch (e: Exception) { label.text = "Kamera $i: błąd adresu" }
            } else label.text = "Kamera $i — ustaw RTSP (skonfiguruj ONVIF / RTSP)"
            view.setOnClickListener { if (url.isNotBlank()) showCameraFullscreen(i, url) }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 1..2) {
            val b = Button(this).apply { text = prefs.getString("name$i", "Link $i") ?: "Link $i"; setOnClickListener { openLink(i) } }
            actions.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(actions)
        root.addView(Button(this).apply { text = "⚙ Ustawienia"; setOnClickListener { showSettings() } })
        setContentView(root)
        handler.removeCallbacks(refresh); handler.post(refresh)
    }

    private fun showCameraFullscreen(index: Int, url: String) {
        screen = "fullscreen"
        handler.removeCallbacks(refresh); releasePlayers()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        root.addView(Button(this).apply { text = "← Powrót do 4 kamer"; setOnClickListener { showDashboard() } })
        val view = PlayerView(this)
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val player = ExoPlayer.Builder(this).build()
        player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.playWhenReady = true
        view.player = player; players.add(player)
    }

    private fun openLink(i: Int) {
        val url = prefs.getString("link$i", "").orEmpty()
        if (!url.startsWith("https://") && !url.startsWith("http://")) { toast("Ustaw prawidłowy link HTTP(S)"); return }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast("Nie można otworzyć linku") }
    }

    private fun showSettings() {
        screen = "settings"
        handler.removeCallbacks(refresh); releasePlayers()
        val scroll = ScrollView(this)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 20, 24, 20) }
        scroll.addView(form)
        val fields = linkedMapOf<String, EditText>()
        fun field(key: String, label: String, secret: Boolean = false) {
            form.addView(TextView(this).apply { text = label; textSize = 16f })
            val edit = EditText(this).apply {
                setSingleLine(true); setText(prefs.getString(key, ""))
                if (secret) inputType = 129
            }
            fields[key] = edit; form.addView(edit)
        }
        form.addView(TextView(this).apply { text = "USTAWIENIA XMEye / SUPLA"; textSize = 21f })
        form.addView(TextView(this).apply {
            text = "XMEye: aplikacja odtwarza strumienie RTSP udostępniane przez rejestrator/kamery. Sam numer seryjny P2P XMEye NIE umożliwia połączenia. Sprawdź w ustawieniach rejestratora RTSP / ONVIF i użyj lokalnego IP albo bezpiecznego VPN. Nie wystawiaj portu RTSP bezpośrednio do Internetu."
            setPadding(0, 12, 0, 12)
        })
        form.addView(TextView(this).apply { text = "Techage ONVIF: wpisz adres usługi, np. http://192.168.1.100/onvif/device_service, login i hasło. Następnie wybierz Pobierz RTSP. Telefon musi mieć dostęp do kamery w sieci lokalnej lub przez VPN." })
        for (i in 1..4) {
            field("onvif$i", "Kamera $i — adres usługi ONVIF")
            field("user$i", "Kamera $i — użytkownik ONVIF")
            field("pass$i", "Kamera $i — hasło ONVIF", true)
            field("camera$i", "Kamera $i — RTSP (uzupełniany automatycznie lub ręcznie)")
            form.addView(Button(this).apply { text = "Pobierz RTSP z ONVIF — kamera $i"; setOnClickListener {
                val device = fields["onvif$i"]!!.text.toString().trim()
                val user = fields["user$i"]!!.text.toString().trim()
                val pass = fields["pass$i"]!!.text.toString()
                if (device.isBlank()) { toast("Wpisz adres ONVIF kamery $i"); return@setOnClickListener }
                isEnabled = false
                val button = this
                Thread {
                    val result = runCatching { OnvifClient.streamUri(device, user, pass) }
                    runOnUiThread {
                        button.isEnabled = true
                        result.onSuccess { uri -> fields["camera$i"]!!.setText(uri); toast("Pobrano RTSP kamery $i — zapisz ustawienia") }
                            .onFailure { err -> toast("ONVIF kamera $i: ${err.message}") }
                    }
                }.start()
            } })
        }
        form.addView(TextView(this).apply {
            text = "SUPLA: skopiuj adres HTTPS kanału temperatury i token dostępu z konta SUPLA. Token przechowuj prywatnie."
            setPadding(0, 12, 0, 8)
        })
        field("suplaUrl", "SUPLA — pełny adres HTTPS endpointu kanału")
        field("suplaToken", "SUPLA — token OAuth Bearer", true)
        for (i in 1..2) { field("name$i", "Nazwa przycisku $i"); field("link$i", "Adres URL przycisku $i") }
        form.addView(Button(this).apply { text = "Zapisz i wróć"; setOnClickListener {
            prefs.edit().apply { fields.forEach { (k, v) -> putString(k, v.text.toString().trim()) } }.apply()
            showDashboard()
        } })
        setContentView(scroll)
    }

    private fun fetchTemperature() {
        val endpoint = prefs.getString("suplaUrl", "").orEmpty()
        val token = prefs.getString("suplaToken", "").orEmpty()
        if (!endpoint.startsWith("https://") || token.isBlank()) { temperature.text = "Temperatura: skonfiguruj SUPLA"; return }
        val request = try { Request.Builder().url(endpoint).header("Authorization", "Bearer $token").build() }
        catch (_: IllegalArgumentException) { temperature.text = "Temperatura: nieprawidłowy adres SUPLA"; return }
        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { runOnUiThread { temperature.text = "Temperatura: brak połączenia" } }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val value = try {
                        if (!it.isSuccessful) null else {
                            val json = JSONObject(it.body?.string().orEmpty())
                            val nested = json.optJSONObject("value")
                            when {
                                nested?.has("temperature") == true -> nested.optDouble("temperature")
                                json.has("temperature") -> json.optDouble("temperature")
                                else -> null
                            }
                        }
                    } catch (_: Exception) { null }
                    runOnUiThread { temperature.text = if (value != null && !value.isNaN()) "Temperatura: %.1f °C".format(value) else "Temperatura: brak odczytu" }
                }
            }
        })
    }

    private fun releasePlayers() { players.forEach { it.release() }; players.clear() }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onStart() {
        super.onStart()
        if (stopped && screen == "dashboard") showDashboard()
        stopped = false
    }
    override fun onStop() {
        stopped = true
        handler.removeCallbacks(refresh)
        releasePlayers()
        super.onStop()
    }
    override fun onDestroy() { handler.removeCallbacks(refresh); releasePlayers(); super.onDestroy() }
    override fun onBackPressed() { if (screen == "dashboard") super.onBackPressed() else showDashboard() }
}
